# Design System Strategy: Editorial Kineticism

## 1. Overview & Creative North Star

This design system is built upon the concept of **"The Kinetic Gallery."** It treats the digital interface not as a software application, but as a high-end editorial publication where white space is an active participant and color is a calculated event. 

The Creative North Star is defined by **Sophisticated Tension**: the balance between a vast, calm white canvas and the high-energy pulse of scarlet gradients. We break the "template" look by rejecting traditional containers and rigid grids. Instead, we use intentional asymmetry—placing display type off-center and allowing crimson elements to bleed into margins—to create a sense of movement and "visual soul."

## 2. Colors & Tonal Architecture

Our palette is grounded in professional neutrals with a high-performance red accent system.

### The "No-Line" Rule
Standard UI relies on 1px borders to separate content. This design system **prohibits** 1px solid borders for sectioning. Boundaries must be defined solely through:
- **Background Color Shifts:** A section using `surface-container-low` (#f3f4f5) sitting atop a `surface` (#f8f9fa) background.
- **Tonal Transitions:** Using the hierarchy of containers to suggest edges without drawing them.

### Surface Hierarchy & Nesting
Treat the UI as a physical stack of fine paper. 
- **Base Layer:** `surface` (#f8f9fa) for the main canvas.
- **Structural Nesting:** Use `surface-container-lowest` (#ffffff) for elevated content cards and `surface-container-high` (#e7e8e9) for recessed utility areas like sidebars or footers. This creates a natural "nested" depth that feels architectural.

### Signature Textures & Gradients
To achieve the "sophisticated crimson to scarlet" request, all primary interactive elements must use a linear gradient:
- **Primary Gradient:** 135° transition from `primary` (#b90014) to `primary_container` (#e31b23). 
- This gradient provides the professional polish that flat color lacks, giving buttons a tactile, gem-like quality.

## 3. Typography: The Editorial Voice

We utilize a dual-font strategy to balance character with utility.

- **The Display Voice (Manrope):** Used for `display-*` and `headline-*` scales. Manrope’s geometric yet warm structure conveys modern authority. Use `display-lg` (3.5rem) with tight letter-spacing (-0.02em) to create high-impact editorial moments.
- **The Functional Voice (Inter):** Used for `title-*`, `body-*`, and `label-*`. Inter is the workhorse. It ensures that even at `body-sm` (0.75rem), complex data remains legible.
- **Hierarchy as Identity:** Use extreme contrast in scale. Pair a `display-md` headline with a `body-md` description to create the "magazine" feel. Avoid using middle-range sizes (like headline-sm) too frequently; go big or go quiet.

## 4. Elevation & Depth

We move away from the "floating shadow" aesthetic of 2014 and toward **Tonal Layering**.

- **The Layering Principle:** Depth is achieved by "stacking." A `surface-container-lowest` (#ffffff) card placed on a `surface-container-low` (#f3f4f5) background provides a soft lift that is felt rather than seen.
- **Ambient Shadows:** For floating elements (modals/dropdowns), use extra-diffused shadows. The shadow must be tinted with the `on-surface` color at 4-8% opacity with a blur radius of 40px or higher. This mimics natural light.
- **Glassmorphism:** Use `surface_container_lowest` at 85% opacity with a `24px` backdrop blur for floating headers or navigation bars. This allows the signature red gradients to peek through the frost, integrating the layout.
- **The "Ghost Border":** If a border is required for accessibility, use the `outline-variant` (#e7bdb8) at 20% opacity. 100% opaque borders are forbidden.

## 5. Components

### Buttons
- **Primary:** Features the signature crimson-to-scarlet gradient. Roundedness: `md` (0.375rem). 
- **Secondary:** Transparent background with a "Ghost Border" (20% opacity `outline-variant`). Text color: `primary`.
- **States:** On hover, the primary gradient should shift +10% in brightness to create a "glow" effect.

### Input Fields
- **Surface:** Use `surface-container` (#edeeef). 
- **Shape:** `sm` (0.125rem) for a sharper, more professional look.
- **Interactions:** No border in default state. On focus, a 2px bottom-bar using the `primary` color emerges, suggesting a "premium stationery" feel.

### Cards & Lists
- **The "No-Divider" Rule:** Forbid the use of 1px lines between list items. Use vertical white space (1.5rem to 2rem) or alternating tonal shifts (e.g., `surface` to `surface-container-low`) to separate content.
- **Composition:** Content should be padded with a minimum of `2rem` to allow the Manrope typography to breathe.

### Chips
- **Style:** Use `surface-container-highest` with `label-md` Inter text. Roundedness: `full` (9999px). This provides a soft, pill-shaped contrast to the sharper input fields.

## 6. Do’s and Don’ts

### Do:
- **Embrace White Space:** Use the `surface` background as a design element, not just a gap.
- **Use Asymmetric Grids:** Align text to the left but allow imagery or accents to bleed off the right edge of the viewport.
- **Prioritize Legibility:** Ensure `on-surface` text on `surface` backgrounds always hits a 4.5:1 contrast ratio.

### Don’t:
- **Don’t use "Default" Shadows:** Avoid high-contrast, tight-radius shadows that look like "drop shadows."
- **Don’t Overuse Red:** The crimson gradient is a scalpel, not a sledgehammer. Use it for CTAs and highlights, never for large background blocks.
- **Don’t use 1px Dividers:** If you feel the need for a line, use a 12px gap of `surface-container-low` instead.
- **Don't use pure black:** Use `on-background` (#191c1d) for text to maintain the sophisticated, high-end softness.