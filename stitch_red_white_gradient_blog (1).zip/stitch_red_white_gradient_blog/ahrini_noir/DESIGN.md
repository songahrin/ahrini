# Design System Specification: High-End Editorial

## 1. Overview & Creative North Star: "The Kinetic Canvas"

This design system is built upon the concept of **The Kinetic Canvas**. It rejects the static, boxy nature of traditional web templates in favor of an editorial experience that feels both surgically clean and vibrantly alive. 

Inspired by high-end digital showcases, the system utilizes a "sophisticated energy" approach. We achieve this by pairing a vast, sterile white landscape with high-velocity primary accents. We break the grid through intentional asymmetry—think large-scale typography overlapping container edges and content that breathes through expansive white space. This is not just a blog; it is a curated gallery of thought.

---

## 2. Colors & Surface Philosophy

The color palette is rooted in high-contrast sophistication. While the background remains a crisp `#faf8ff`, the energy is driven by the depth of the primary indigo-to-vibrant tones and the tactical use of surface tiers.

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders to define sections, cards, or containers. Structure must be felt, not seen. Boundaries are created through:
- **Tonal Shifts:** Transitioning from `surface` to `surface-container-low`.
- **Negative Space:** Using the Spacing Scale to isolate elements.
- **Glassmorphism:** Using `surface` colors at 70-80% opacity with a `20px` backdrop-blur to create a "frost" effect over background gradients.

### Surface Hierarchy & Nesting
Treat the UI as a series of physical layers. Use the hierarchy below to "stack" importance:
1.  **Base Layer:** `surface` (#faf8ff) – The infinite canvas.
2.  **Sectional Layer:** `surface-container-low` (#f2f3ff) – Large content blocks.
3.  **Interactive Layer:** `surface-container-lowest` (#ffffff) – Floating cards or high-priority inputs.

### The "Glass & Gradient" Rule
To inject "soul" into the minimal aesthetic, use **Signature Textures**. Hero sections and primary CTAs should utilize a subtle linear gradient (135°) transitioning from `primary` (#3525cd) to `primary_container` (#4f46e5). This creates a sense of light and movement that flat hex codes cannot replicate.

---

## 3. Typography: The Editorial Voice

We use **Inter** exclusively, but we treat it with the reverence of a print magazine. The hierarchy is designed to create a rhythmic flow between massive, authoritative statements and quiet, readable details.

*   **Display (lg/md):** Use for hero statements. Tracking should be set to `-0.02em` to create a tight, custom-type feel. 
*   **Headline (lg/md):** Used for article titles. Ensure a line-height of `1.1` to maintain high-impact density.
*   **Body (lg/md):** The workhorse. Set in `on_surface_variant` (#464555) to reduce eye strain against the stark white background.
*   **Labels:** Use `label-md` in uppercase with `0.05em` letter spacing for categorization (e.g., "FEATURED," "5 MIN READ").

---

## 4. Elevation & Depth: Tonal Layering

Depth is a tool for focus, not decoration. We move away from heavy drop shadows toward **Ambient Light.**

*   **The Layering Principle:** Place a `surface-container-lowest` card on a `surface-container` background. This creates a natural, soft "lift" that feels integrated into the environment.
*   **Ambient Shadows:** For floating elements (Modals, Popovers), use a shadow with a blur radius of `40px-60px` at `6%` opacity, using the `on_surface` color as the shadow base. It should look like a soft glow of shadow, not a hard edge.
*   **The "Ghost Border" Fallback:** If accessibility requires a container edge, use the `outline_variant` token at **15% opacity**. This creates a "suggestion" of a border that disappears into the background upon quick glance.

---

## 5. Components

### Buttons
*   **Primary:** A vibrant gradient of `primary` to `primary_container`. Border-radius: `full`. No shadow. On hover: a subtle scale-up (1.02x) and an increased brightness.
*   **Secondary:** `surface_container_highest` background with `primary` text. This provides a tactile feel without competing with the primary action.
*   **Tertiary:** Pure text with a 2px underline using `primary` at 30% opacity, which expands to 100% on hover.

### Cards & Feed Items
**Strict Rule:** No dividers. Separate blog posts in a feed using `48px` or `64px` of vertical white space. 
*   Use a subtle `surface-container-low` background on the card that transitions to `surface-container-high` on hover to signal interactivity.

### Input Fields
*   **Minimalist Frame:** No background color. Only a bottom-aligned "Ghost Border" (15% opacity `outline_variant`). 
*   **Active State:** The bottom border transforms into a 2px `primary` solid line with a smooth `200ms` transition.

### Chips (Categories)
*   Used for tags. Style with `secondary_container` background and `on_secondary_container` text. Use `md` (0.75rem) roundedness for a modern, slightly technical look.

---

## 6. Do's and Don'ts

### Do:
*   **Do** allow elements to bleed off the edge of their containers in hero sections to create an "uncontained" energy.
*   **Do** use `surface_bright` for areas intended to draw the eye first.
*   **Do** lean into extreme white space. If it feels like "too much," it’s likely just right for this system.

### Don't:
*   **Don't** use 100% black (#000000). Always use `on_surface` (#131b2e) for text to maintain tonal harmony.
*   **Don't** use standard "Box Shadows" from CSS frameworks. Always tint your shadows with the background color for a premium, ambient effect.
*   **Don't** use dividers or lines to separate content. Use the `surface` color shifts or spacing instead.